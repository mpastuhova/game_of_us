A GAME OF US — QUICK START

Files:
- index.html: the complete website. No build step or coding tools required.

PREVIEW ON YOUR MAC
1. Double-click index.html to open it in your browser.
2. Try the chess move: click the white pawn on e2, then the highlighted e4 square. Or use the Enter button.
3. Explore the gallery, soundtrack, and secret buttons.

PUBLISH WITH GITHUB PAGES (FREE)
1. Create/sign into https://github.com
2. Click +, then New repository.
3. Name it: a-game-of-us (or another name). Set it to Public and add a README if you like.
4. In the repository, click Add file > Upload files.
5. Upload index.html (and this README if desired), then Commit changes.
6. Go to Settings > Pages.
7. Under Build and deployment, choose Deploy from a branch. Select main and /(root), then Save.
8. Wait a few minutes and refresh Settings > Pages. Your site should appear at https://YOUR-USERNAME.github.io/a-game-of-us/

IMPORTANT PRIVACY NOTE
GitHub Pages sites are public. Do not upload photos or personal details you would not want to be publicly accessible. A hard-to-guess URL is not password protection.

PERSONALISE PHOTOS
For easiest editing, upload photos into a folder named photos in the repository. In index.html, find a photo card and change data-image="" to data-image="photos/your-photo.jpg". Replace the title/caption text in data-title and data-caption. Use filenames without spaces if possible.

PERSONALISE MUSIC
Find the Our Soundtrack section in index.html. Replace song titles, artists, notes, and the example Spotify URLs.

PERSONALISE SECRET MESSAGES
Find data-secret in the Secret Moves section and change the text between its quotes. Avoid using quotation marks inside the value unless you escape them.

NOTE
The opening interaction is a deliberately small, guided chess move (e2 to e4), not a full chess engine/game. The remaining site is plain HTML/CSS/JavaScript and needs no paid services.
